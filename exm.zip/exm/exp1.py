import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error,r2_score
from sklearn.linear_model import LinearRegression

df=pd.read_csv("housing.csv").dropna()
df["avg_rooms"]=df["total_rooms"]/df["households"]
x=df["avg_rooms"].values
y=df["median_house_value"].values
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)
mean,std=x_train.mean(),x_train.std()
x_train=(x_train-mean)/std
x_test=(x_test-mean)/std
b0,b1,lr,iterations=0,0,0.01,1000
n=len(x_train)
cost_history=[]
for i in range(iterations):
    pred=b0+b1*x_train
    cost_history.append(np.mean((y_train-pred)**2))
    db0=(-2/n)*np.sum(y_train-pred)
    db1=(-2/n)*np.sum(x_train*(y_train-pred))
    b0-=lr*db0          
    b1-=lr*db1
pred=b0+b1*x_test
print("Gradient Descent")
print("intercept:",b0)
print("slope:",b1)
print("MSE:",mean_squared_error(y_test,pred))
print("R2 score:",r2_score(y_test,pred))
plt.title("Gradient Decent")
plt.scatter(x_test,y_test,label="actual data")
plt.plot(x_test,pred,"r-",label="gradient descent line")
plt.xlabel("normalized average rooms")
plt.ylabel("median house values")
plt.legend()
plt.show()

plt.plot(cost_history)
plt.title("cost function convergence")
plt.xlabel("iteration")
plt.ylabel("cost")
plt.grid()
plt.show()
#hey u should add *std+mean to xtrain and xtest
model=LinearRegression()
model.fit(x_train.reshape(-1,1),y_train)
pred=model.predict(x_test.reshape(-1,1))
print("\nLeast Square")
print("intercept:",model.intercept_)
print("slope:",model.coef_[0])
print("MSE:",mean_squared_error(y_test,pred))
print("R2 score:",r2_score(y_test,pred))
plt.title("Least Square")
plt.scatter(x_test,y_test,label="actual data")
plt.plot(x_test,pred,"r-",label="Regression line")
plt.xlabel("normalized average rooms")
plt.ylabel("median house values")
plt.legend()
plt.show()
