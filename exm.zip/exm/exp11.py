
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets, svm

# Load Iris dataset
iris = datasets.load_iris()

X = iris.data[:, :2]
y = np.where(iris.target == 0, 1, -1)

# Train Linear SVM
model = svm.SVC(kernel='linear', C=1)
model.fit(X, y)

# Plot data points
plt.scatter(X[:, 0], X[:, 1], c=y, cmap='coolwarm')

# Create grid for drawing lines
ax = plt.gca()
xlim = ax.get_xlim()
ylim = ax.get_ylim()

xx, yy = np.meshgrid(
    np.linspace(xlim[0], xlim[1], 100),
    np.linspace(ylim[0], ylim[1], 100)
)

# Calculate decision values
Z = model.decision_function(
    np.c_[xx.ravel(), yy.ravel()]
).reshape(xx.shape)

# Draw boundary and margins
ax.contour(
    xx, yy, Z,
    levels=[-1, 0, 1],
    colors=['blue', 'black', 'blue'],
    linestyles=['--', '-', '--']
)

# Highlight support vectors
ax.scatter(
    model.support_vectors_[:, 0],
    model.support_vectors_[:, 1],
    s=100,
    facecolors='none',
    edgecolors='green'
)

plt.xlabel("Sepal Length (cm)")
plt.ylabel("Sepal Width (cm)")
plt.title("Linear SVM on Iris Dataset")
plt.show()
