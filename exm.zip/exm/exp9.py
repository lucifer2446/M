
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier, plot_tree
import matplotlib.pyplot as plt

# Load the dataset
data = pd.read_excel("Online Retail.xlsx")

# Remove rows without CustomerID
data = data.dropna(subset=["CustomerID"])

# Calculate total amount
data["TotalAmount"] = data["Quantity"] * data["UnitPrice"]

# Create customer-level table
customer_data = data.groupby("CustomerID").agg(
    TotalSpend=("TotalAmount", "sum"),
    TotalItems=("Quantity", "sum"),
    NumInvoices=("InvoiceNo", "nunique")
).reset_index()

# Create customer class
customer_data["CustomerType"] = np.where(
    customer_data["TotalSpend"] >= customer_data["TotalSpend"].median(),
    "High",
    "Low"
)

# Select input features and target
X = customer_data[["TotalItems", "NumInvoices"]]
y = customer_data["CustomerType"]

# Implement the ID3 decision tree
model = DecisionTreeClassifier(
    criterion="entropy",
    max_depth=3,
    random_state=42
)

model.fit(X, y)

# Display feature importance
print("Feature Importance:")
for feature, value in zip(X.columns, model.feature_importances_):
    print(feature, ":", value)

# Display the decision tree
plt.figure(figsize=(12, 7))
plot_tree(
    model,
    feature_names=X.columns,
    class_names=model.classes_,
    filled=True
)
plt.show()
